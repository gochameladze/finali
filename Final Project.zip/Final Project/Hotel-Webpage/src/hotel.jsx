import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import RoomCard from './RoomCard';
import MasterRoom from './pictures/pic1.jpg';
import RoofPool from './pictures/pic2.jpg';
import Pool from './pictures/pic3.jpg';
import MasterBedroom from './pictures/pic4.jpg';
import SmallRoom1 from './pictures/pic5.jpg';
import SmallRoom2 from './pictures/pic6.jpg';
import SmallRoom3 from './pictures/pic7.jpg';
import SmallRoom4 from './pictures/pic8.jpg';

const services = [
  { id: 1, name: 'MasterRoom', image: MasterRoom, price: 800, type: 'Bedroom', visibility: 'active' },
  { id: 2, name: 'RoofPool', image: RoofPool, price: 20, type: 'Pool', visibility: 'active' },
  { id: 3, name: 'Pool', image: Pool, price: 20, type: 'Pool', visibility: 'active' },
  { id: 4, name: 'MasterBedroom', image: MasterBedroom, price: 800, type: 'Bedroom', visibility: 'active' },
  { id: 5, name: 'SmallRoom1', image: SmallRoom1, price: 500, type: 'Room', visibility: 'active' },
  { id: 6, name: 'SmallRoom2', image: SmallRoom2, price: 400, type: 'Room', visibility: 'active' },
  { id: 7, name: 'SmallRoom3', image: SmallRoom3, price: 300, type: 'Room', visibility: 'active' },
  { id: 8, name: 'SmallRoom4', image: SmallRoom4, price: 300, type: 'Room', visibility: 'active' },
];

function hotel() {
  const [filteredRooms, setFilteredRooms] = useState(services);
  const [sortOrder, setSortOrder] = useState('');

  const handleFilter = (type) => {
    if (type === 'All') {
      setFilteredRooms(services);
    } else {
      setFilteredRooms(services.filter(room => room.type === type));
    }
  };

  const handleSort = (order) => {
    setSortOrder(order);
    const sortedRooms = [...filteredRooms].sort((a, b) =>
      order === 'asc' ? a.price - b.price : b.price - a.price
    );
    setFilteredRooms(sortedRooms);
  };

  return (
    <div className="hotel">
      <div className="home">
        <h1>Welcome to Our Hotel</h1>
        <p>Explore our rooms and book your stay!</p>
        <div className="navigation">
          <Link to="/rooms">View Our Rooms</Link>
          <Link to="/signup">Sign Up</Link>
          <a href="#social">Visit us on Social Media</a>
          <select>
            <option value="en">English</option>
            <option value="ru">Russian</option>
            <option value="geo">Georgian</option>
          </select>
        </div>
      </div>
      <section id="rooms">
        <h2>Rooms</h2>
        <div className="filter">
          <h3>Filter by Type</h3>
          <select onChange={(e) => handleFilter(e.target.value)}>
            <option value="All">All</option>
            <option value="Bedroom">Bedroom</option>
            <option value="Pool">Pool</option>
            <option value="Room">Room</option>
          </select>
        </div>
        <div className="sort">
          <h3>Sort by Price</h3>
          <button onClick={() => handleSort('asc')}>Ascending</button>
          <button onClick={() => handleSort('desc')}>Descending</button>
        </div>
        <div className="room-catalog">
          {filteredRooms.map(room => (
            <div key={room.id} className="room-card">
              <img src={room.image} alt={room.name} />
              <h4>{room.name}</h4>
              <p>Price: ${room.price}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default hotel;
import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
return (
<nav className="navbar">
<ul>
<li><Link to="/">Home</Link></li>
<li><Link to="/about">About Us</Link></li>
<li><Link to="/contact">Contact</Link></li>
<li><Link to="/login">Log In</Link></li>
<li><Link to="/signup">Sign Up</Link></li>
</ul>
<form className="search-form">
<input type="text" placeholder="Search..." />
<button type="submit">Search</button>
</form>
</nav>
);
}

export default Navbar;
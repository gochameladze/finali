import React from 'react';

const AuthForms = () => (
  <div>
    <h1>Sign Up</h1>
    <form>
      <input type="email" placeholder="Email" required />
      <input type="password" placeholder="Password" required />
      <button type="submit">Sign Up</button>
    </form>
    <button>Sign Up with Facebook</button>
    <button>Sign Up with Google</button>
  </div>
);

export default AuthForms;

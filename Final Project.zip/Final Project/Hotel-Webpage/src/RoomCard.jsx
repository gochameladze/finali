import React, { useState } from 'react';

function RoomCard({ room }) {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingData, setBookingData] = useState({
    name: '',
    email: '',
    checkInDate: '',
    checkOutDate: ''
  });

  const handleBookClick = () => {
    setIsBookingOpen(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setBookingData({ ...bookingData, [name]: value });
  };

  const handleSubmitBooking = (e) => {
    e.preventDefault();
    // Handle booking submission logic here (e.g., send booking data to server)
    setIsBookingOpen(false);
    console.log('Booking data:', bookingData);

    // Calculate total price
    const totalPrice = calculateTotalPrice(
      bookingData.checkInDate,
      bookingData.checkOutDate,
      room.price
    );
    console.log('Total Price:', totalPrice);

  };

  // Function to calculate total price based on number of days
  const calculateTotalPrice = (checkInDate, checkOutDate, pricePerNight) => {
    const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    const startDate = new Date(checkInDate);
    const endDate = new Date(checkOutDate);
    const totalDays = Math.round(Math.abs((startDate - endDate) / oneDay));
    return totalDays * pricePerNight;
  };

  return (
    <div className="room-card">
      <img src={room.image} alt={room.name} />
      <h4>{room.name}</h4>
      <p>Type: {room.type}</p>
      <p>Price: ${room.price}</p>
      <button onClick={handleBookClick}>Book Now</button>

      {/* Booking Form */}
      {isBookingOpen && (
        <form onSubmit={handleSubmitBooking}>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={bookingData.name}
            onChange={handleInputChange}
            required
          />
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={bookingData.email}
            onChange={handleInputChange}
            required
          />
          <label>Check-in Date:</label>
          <input
            type="date"
            name="checkInDate"
            value={bookingData.checkInDate}
            onChange={handleInputChange}
            required
          />
          <label>Check-out Date:</label>
          <input
            type="date"
            name="checkOutDate"
            value={bookingData.checkOutDate}
            onChange={handleInputChange}
            required
          />
          <button type="submit">Confirm Booking</button>
        </form>
      )}
    </div>
  );
}

export default RoomCard;

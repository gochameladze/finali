import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navbar';
import Hotel from './Hotel';
import AuthForms from './AuthForms'; // Import AuthForms component
import ContactForm from './ContactForm';
import RoomCard from './RoomCard';
import './App.css'; // Import your CSS file


function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<Hotel />} /> {/* Render Hotel component */}
          <Route path="/room/:id" element={<RoomCard />} /> {/* Render RoomCard component */}
          <Route path="/auth" element={<AuthForms />} /> {/* Render AuthForms component */}
          <Route path="/contact" element={<ContactForm />} /> {/* Render ContactForm component */}
          {/* Add more routes for other pages if needed */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;

   